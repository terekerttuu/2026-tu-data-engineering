# Project Overview — For the Team

This document explains what we built, how it fits together, and what each person is responsible for.
Read this before touching any code.

---

## The question we are answering

> How is the ECB deposit facility rate related to the 30-day returns of STOXX Europe 600 sector indices?

In plain terms: when the ECB raises or cuts interest rates, which sectors of the European stock market react, and by how much?

We produce three concrete outputs:
1. A **descriptive chart** — sector prices and the ECB rate plotted over the same time period.
2. **Average 30-day sector returns** after each ECB rate decision (hike or cut).
3. **Beta coefficients** per sector — a single number showing how sensitive each sector is to a 1 basis point rate change.

---

## The stack

| What | Tool | Why |
|------|------|-----|
| Orchestration | Apache Airflow | Schedules and runs the pipeline daily |
| Data fetch | Python (inside Airflow) | Pulls from ECB API and Yahoo Finance |
| Transformation | dbt (inside Airflow) | SQL models that clean and aggregate the data |
| Storage | PostgreSQL (pgDuckDB) | Holds all raw and transformed data |
| Dashboard | Apache Superset | Connects to PostgreSQL and renders charts |
| Infrastructure | Docker Compose | Runs everything locally with one command |

Everything runs in Docker — you don't install dbt or Airflow on your machine directly.

---

## How the data flows

```
ECB API ──────────────────────┐
                               ├──► staging (raw tables) ──► dbt ──► marts ──► Superset
Yahoo Finance (yfinance) ─────┘
```

More specifically, every day Airflow runs this sequence:

```
dbt seed → [fetch ECB rates ∥ fetch prices] → dbt run → dbt test
```

1. **dbt seed** loads `dim_sectors.csv` into the database — the list of 19 sector ETF tickers.
2. **Fetch ECB rates** hits the ECB public API and inserts the full rate history into `staging.ecb_rates_raw`.
3. **Fetch prices** reads the active tickers from the database, then pulls daily prices from Yahoo Finance into `staging.index_prices_raw`. On the first run this fetches 10 years of history. After that, only new days are added.
4. **dbt run** transforms everything through three layers (explained below).
5. **dbt test** checks that no required columns are null, keys are unique, etc.

---

## The three database layers

### Staging — "what did we receive, cleaned up"

Two raw tables (`ecb_rates_raw`, `index_prices_raw`) hold everything Airflow has ever fetched.
They are **append-only** — nothing is ever deleted or updated. Each Airflow run gets a unique
`run_id` (a UUID), so we always know when data came in and from which run.

On top of these, dbt creates two **views** (`stg_ecb_rates`, `stg_index_prices`) that deduplicate
the raw tables — if the same date was fetched in multiple runs, only the most recent version is shown.

This pattern is called **idempotency**: you can re-run the pipeline as many times as you want
and the clean data always looks the same. Airflow writes blindly; dbt deduplicates cleanly.

### Intermediate — "derived calculations, not yet the final answer"

Two more **views** (not stored tables — they're computed on the fly when queried):

- `int_sector_returns` — daily percentage return per sector, computed from closing prices using a LAG window function.
- `int_aligned_ecb_rates` — the ECB rate forward-filled to every trading day. ECB decides 5–8 times per year; markets trade every weekday. For each trading day, this view tells you what rate was in effect.

### Marts — "the final answers, ready for the dashboard"

Three **tables** (materialised — stored on disk, fast to query):

- `mart_prices_and_rates` — every trading day, for every sector: closing price + ECB rate. Input for the descriptive time-series chart.
- `mart_post_event_returns` — for each ECB decision, what was each sector's cumulative return over the following 30 calendar days? One row per (decision date, sector).
- `mart_sector_betas` — OLS linear regression result per sector. Beta = how much the sector's 30-day return changes for a 1 basis point rate move. Computed entirely in SQL.

---

## The sector dimension — `dim_sectors`

The file `dbt_project/seeds/dim_sectors.csv` lists all 19 sector ETFs we track. It uses a
`valid_from` / `valid_to` structure:

```
ticker,sector_name,valid_from,valid_to
EXV1.DE,Banks,1999-01-01,9999-01-01
...
```

`valid_to = 9999-01-01` means "currently active". If a ticker ever changes (rare but possible),
we set `valid_to` to the retirement date and add a new row — rather than overwriting the old one.
This way historical data always joins correctly to the ticker that was valid at that time.

The pipeline reads active tickers dynamically from this table at runtime, so adding or retiring
a sector never requires touching the DAG code.

---

## Data sources

### ECB Deposit Facility Rate
- **URL:** `https://data-api.ecb.europa.eu/service/data/FM/B.U2.EUR.4F.KR.DFR.LEV?format=csvdata&detail=dataonly`
- **Access:** Public, no API key needed.
- **Format:** CSV with two columns: `TIME_PERIOD` (decision date) and `OBS_VALUE` (rate in %).
- **Update frequency:** Only changes when the ECB Governing Council makes a decision (roughly 8 times per year).
- **Strategy:** We fetch the full history every run (only ~30–40 rows, very cheap).

### Yahoo Finance sector ETFs (via `yfinance`)
- **What:** iShares STOXX Europe 600 sector sub-index ETFs traded on XETRA (German exchange, `.DE` suffix).
- **Access:** Public, no API key needed.
- **Format:** Daily OHLCV (Open, High, Low, Close, Volume). We use adjusted Close for return calculations.
- **Update frequency:** Every trading day.
- **Strategy:** Incremental — first run fetches 10 years, subsequent runs fetch only days since the last known date (with a 5-day overlap for safety).

---

## Team responsibilities

| Person | Role | What to work on |
|--------|------|-----------------|
| **Argo** | Data source owner | Airflow DAG (`airflow/dags/ecb_pipeline.py`), API connections, keeping the pipeline running |
| **Kristjan** | Transformation owner | dbt models (`dbt_project/models/`), writing and maintaining SQL logic |
| **Kerttu** | Quality owner | dbt tests (`schema.yml` files), reviewing failed test runs |
| **Liis** | Dashboard owner | Superset charts and dashboard, connecting Superset to the database |

---

## What is already built

- Full Docker stack (Airflow + PostgreSQL + Superset) — `compose.yml`
- Database schema and raw tables — `init/01_create_schemas.sql`
- Airflow DAG with both data fetchers — `airflow/dags/ecb_pipeline.py`
- All dbt models (staging, intermediate, marts) — `dbt_project/models/`
- Sector dimension seed — `dbt_project/seeds/dim_sectors.csv`
- Basic dbt tests on primary keys and not-null constraints — `schema.yml` files

## What still needs work

- **Kerttu:** Extend dbt tests — add uniqueness combinations (e.g. `(event_date, ticker)` in `mart_post_event_returns`), value range checks (rate between -1 and 15), and relationship tests between models.
- **Liis:** Open Superset, add the `analytics-db` database connection, and build the three charts corresponding to the three metrics. See `docs/getting-started.md` for the connection string.
- **Everyone:** Run the stack at least once locally and confirm the data looks reasonable. The first real run is the best way to find gaps.

---

## Project file structure

```
.
├── compose.yml                        ← Docker stack definition (all services)
├── .env.example                       ← Copy to .env, fill in secrets, never commit .env
├── Dockerfile.superset                ← Superset image with psycopg2 added
├── init/
│   └── 01_create_schemas.sql          ← Creates schemas and raw tables (runs once on first boot)
├── airflow/
│   └── dags/
│       └── ecb_pipeline.py            ← The Airflow DAG (Argo's main file)
├── dbt_project/
│   ├── dbt_project.yml                ← dbt project config (layer → schema mapping)
│   ├── profiles.yml                   ← dbt database connection (reads from env vars)
│   ├── seeds/
│   │   └── dim_sectors.csv            ← 19 sector ETFs with valid_from/valid_to
│   ├── macros/
│   │   └── generate_schema_name.sql   ← Makes dbt use exact schema names (not prefixed)
│   └── models/
│       ├── staging/
│       │   ├── sources.yml            ← Declares raw tables as dbt sources
│       │   ├── stg_ecb_rates.sql      ← Deduplicates ECB raw data
│       │   ├── stg_index_prices.sql   ← Deduplicates price raw data
│       │   └── schema.yml             ← Tests for staging models
│       ├── intermediate/
│       │   ├── int_sector_returns.sql ← Daily % returns via LAG()
│       │   ├── int_aligned_ecb_rates.sql ← ECB rate forward-filled to trading days
│       │   └── schema.yml
│       └── marts/
│           ├── mart_prices_and_rates.sql    ← Metric 1: descriptive chart data
│           ├── mart_post_event_returns.sql  ← Metric 2: 30-day returns per ECB event
│           ├── mart_sector_betas.sql        ← Metric 3: OLS beta per sector
│           └── schema.yml
├── superset/
│   └── superset_config.py             ← Minimal Superset config (cache, CSRF)
└── docs/
    ├── arhitektuur.md                 ← Original architecture document (Estonian)
    ├── getting-started.md             ← How to run the project locally
    └── project-overview.md            ← This file
```
