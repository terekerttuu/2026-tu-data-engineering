# Getting Started — Running the Project Locally
## Step 1 — Clone the repo
## Step 2 — Create your `.env` file

The `.env` file holds passwords and config. It is never committed to Git (it's in `.gitignore`).

```bash
cp .env.example .env
```

Then open `.env` in any text editor and **generate a real secret key for Superset** — this is required, it won't start with the placeholder:

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Copy the output and replace `CHANGE_ME_generate_with_python_secrets` in `.env` with it.

Everything else in `.env` can stay as-is for local development (the default passwords are fine locally).

---

## Step 3 — Start the stack

```bash
docker compose up -d --build
```

The first time this runs it will take **5–10 minutes** — Docker is downloading images (~3 GB total) and installing Python packages (dbt, yfinance) inside the containers. Subsequent starts take under a minute.

You can watch progress with:

```bash
docker compose logs -f
```

Press `Ctrl+C` to stop watching logs (containers keep running).

---

## Step 4 — Check that everything started

```bash
docker compose ps
```

You should see all services with status `running` (or `healthy`). The `ecb-airflow-init` and `ecb-superset-init` containers will show as `exited (0)` — that's normal, they are one-time setup jobs that exit after finishing.

If any container shows `exited (1)` (error), check its logs:

```bash
docker compose logs ecb-airflow-apiserver
# or whichever service failed
```

---

## Step 5 — Open Airflow and run the pipeline

Open [http://localhost:8080](http://localhost:8080) in your browser.

Login: `airflow` / `airflow`

1. Find the DAG called **`ecb_pipeline`** in the list.
2. It will be paused (toggle is grey) — click the toggle to unpause it.
3. Click the **▶ Trigger DAG** button (play icon on the right) to run it immediately.
4. Click on the DAG name to see the run. You'll see 5 tasks:
   - `dbt_seed` → seeds the sector dimension table
   - `laadi_ecb_maarad` → fetches ECB rates (runs in parallel with yfinance)
   - `laadi_indeksite_hinnad` → fetches 10 years of price history from Yahoo Finance
   - `dbt_run` → transforms raw data through staging → intermediate → marts
   - `dbt_test` → runs data quality checks

The first run takes **3–5 minutes** (yfinance downloads 10 years × 19 sectors).

Green boxes = success. Red = something failed — click the task → "Logs" to see why.

---

## Step 6 — Open Superset and connect to the database

Open [http://localhost:8088](http://localhost:8088) in your browser.

Login: `admin` / `admin` (or whatever you set in `.env`)

**Add the analytics database connection** (one-time manual step):

1. Go to **Settings** → **Database Connections** → **+ Database**
2. Select **PostgreSQL**
3. Fill in the connection string:
   ```
   postgresql://praktikum:praktikum@ecb-analytics-db:5432/praktikum
   ```
   > Note: use `ecb-analytics-db` as the host — that's the container name, which Superset can reach because they're on the same Docker network.
4. Click **Test Connection** → should say "Connection looks good!"
5. Click **Connect**

Now you can go to **SQL Lab** → **SQL Editor** and query the marts directly:

```sql
SELECT * FROM marts.mart_sector_betas ORDER BY beta DESC;
SELECT * FROM marts.mart_post_event_returns LIMIT 50;
SELECT * FROM marts.mart_prices_and_rates WHERE ticker = 'EXV1.DE' LIMIT 50;
```

---

## Stopping and restarting

```bash
# Stop everything (data is preserved in Docker volumes)
docker compose down

# Start again later (fast — no rebuild needed)
docker compose up -d

# Nuclear option: stop AND delete all data (volumes)
docker compose down -v
```

---

## Common issues

**Airflow shows "Broken DAG" error**
The DAG file has a Python syntax error or import that failed. Check:
```bash
docker compose logs ecb-airflow-dag-processor
```

**`laadi_indeksite_hinnad` fails with "marts.dim_sectors does not exist"**
The `dbt_seed` task before it failed. Click `dbt_seed` in Airflow → Logs to see why.

**Superset "Connection refused" when testing the database**
Make sure you used `ecb-analytics-db` as the host (the container name), not `localhost`.

**First `docker compose up` takes forever**
Normal — it's installing dbt, yfinance, pandas inside the Airflow containers via pip. Only happens once per fresh build.

**Port already in use (8080, 8088, 55432)**
Something else on your machine is using that port. Change the host port in `.env`:
```
AIRFLOW_PORT_HOST=8081
SUPERSET_PORT_HOST=8089
DB_PORT_HOST=55433
```
